namespace SeralythTemp
{
    public class PluginInfo
    {
        public const string GUID = "org.draxzclient.lol.draxz";
        public const string Name = "draxzclient";
        public const string Description = "Created by justdraxs";
        public const string Version = "1.0.5";
    }
}
