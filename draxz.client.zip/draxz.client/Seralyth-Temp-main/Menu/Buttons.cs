using draxzclient.Mods;
using SeralythTemp.Classes;
using SeralythTemp.Mods;
using UnityEngine;
using static SeralythTemp.Menu.Main;
using static SeralythTemp.Settings;

namespace SeralythTemp.Menu
{
    public class Buttons
    {
        /*
         * Here is where all of your buttons are located.
         * To create a button, you may use the following code:
         * 
         * Move to Category:
         *   new ButtonInfo { buttonText = "Settings", method =() => currentCategory = 1, isTogglable = false, toolTip = "Opens the main settings page for the menu."},
         *   new ButtonInfo { buttonText = "Return to Main", method =() => currentCategory = 0, isTogglable = false, toolTip = "Returns to the main page of the menu."},
         * 
         * Togglable Mod:
         *   new ButtonInfo { buttonText = "Platforms", method =() => Movement.Platforms(), toolTip = "Spawns platforms on your hands when pressing grip."},
         */

        public static ButtonInfo[][] buttons = new ButtonInfo[][]
        {
            new ButtonInfo[] { // Main Mods [0]
                new ButtonInfo { buttonText = "Settings", method =() => currentCategory = 1, isTogglable = false, toolTip = "Opens the main settings page for the menu."},

                new ButtonInfo { buttonText = "Room Mods", method =() => currentCategory = 4, isTogglable = false, toolTip = "Opens the room mods tab."},
                new ButtonInfo { buttonText = "Movement Mods", method =() => currentCategory = 5, isTogglable = false, toolTip = "Opens the movement mods tab."},
                new ButtonInfo { buttonText = "Safety Mods", method =() => currentCategory = 6, isTogglable = false, toolTip = "Opens the safety mods tab."},
                new ButtonInfo { buttonText = "Fun Mods", method =() => currentCategory = 7, isTogglable = false, toolTip = "Opens the fun mods tab."},
                new ButtonInfo { buttonText = "EnabledMods", method =() => currentCategory = 8, isTogglable = false, toolTip = "Opens the enabled mods tab."},
                new ButtonInfo { buttonText = "TimeChanger", method =() => currentCategory = 9, isTogglable = false, toolTip = "Opens the timechanger mods tab."},
            },

            new ButtonInfo[] { // Settings [1]
                new ButtonInfo { buttonText = "Return to Main", method =() => currentCategory = 0, isTogglable = false, toolTip = "Returns to the main page of the menu."},
                new ButtonInfo { buttonText = "Menu", method =() => currentCategory = 2, isTogglable = false, toolTip = "Opens the settings for the menu."},
                new ButtonInfo { buttonText = "Movement", method =() => currentCategory = 3, isTogglable = false, toolTip = "Opens the movement settings for the menu."},
            },

            new ButtonInfo[] { // Menu Settings [2]
                new ButtonInfo { buttonText = "Return to Settings", method =() => currentCategory = 1, isTogglable = false, toolTip = "Returns to the main settings page for the menu."},
                new ButtonInfo { buttonText = "Right Hand", enableMethod =() => rightHanded = true, disableMethod =() => rightHanded = false, toolTip = "Puts the menu on your right hand."},
                new ButtonInfo { buttonText = "Notifications", enableMethod =() => disableNotifications = false, disableMethod =() => disableNotifications = true, enabled = !disableNotifications, toolTip = "Toggles the notifications."},
                new ButtonInfo { buttonText = "FPS Counter", enableMethod =() => fpsCounter = true, disableMethod =() => fpsCounter = false, enabled = fpsCounter, toolTip = "Toggles the FPS counter."},
                new ButtonInfo { buttonText = "Disconnect Button", enableMethod =() => disconnectButton = true, disableMethod =() => disconnectButton = false, enabled = disconnectButton, toolTip = "Toggles the disconnect button."},
                new ButtonInfo { buttonText = "Theme: Default", method =() => Classes.ThemeChanger.NextTheme(), isTogglable = false, toolTip = "Cycles through available themes."},
                new ButtonInfo { buttonText = "Save Config", method =() => Classes.ThemeChanger.SaveConfig(), isTogglable = false, toolTip = "Saves your current theme and mod configuration."},
                new ButtonInfo { buttonText = "Load Config", method =() => Classes.ThemeChanger.LoadConfig(), isTogglable = false, toolTip = "Loads your saved theme and mod configuration."},
            },

            new ButtonInfo[] { // Movement Settings [3]
                new ButtonInfo { buttonText = "Return to Settings", method =() => currentCategory = 1, isTogglable = false, toolTip = "Returns to the main settings page for the menu."},

                new ButtonInfo { buttonText = "Change Fly Speed", overlapText = "Change Fly Speed [Normal]", method =() => Mods.Settings.Movement.ChangeFlySpeed(), isTogglable = false, toolTip = "Changes the speed of the fly mod."},
            },

            new ButtonInfo[] { // Room Mods [4]
                new ButtonInfo { buttonText = "Return to Main", method =() => currentCategory = 0, isTogglable = false, toolTip = "Returns to the main page of the menu."},

                new ButtonInfo { buttonText = "Disconnect", method =() => NetworkSystem.Instance.ReturnToSinglePlayer(), isTogglable = false, toolTip = "Disconnects you from the room."},
            },

            new ButtonInfo[] { // Movement Mods [5]
                new ButtonInfo { buttonText = "Return to Main", method =() => currentCategory = 0, isTogglable = false, toolTip = "Returns to the main page of the menu."},

                new ButtonInfo { buttonText = "Platforms", method =() => Movement.Platforms(), toolTip = "Spawns platforms on your hands when pressing grip."},
                new ButtonInfo { buttonText = "Fly", method =() => Movement.Fly(), toolTip = "Sends you forward when holding A."},
                new ButtonInfo { buttonText = "Teleport Gun", method =() => Movement.TeleportGun(), toolTip = "Teleports you to wherever your pointer is when pressing trigger."},
                new ButtonInfo { buttonText = "WASD Fly", method =() => Movement.WASDFly(), disableMethod =() => { Movement.lastPosition = Vector3.zero; GorillaTagger.Instance.rigidbody.useGravity = true; }, toolTip = "Hold right click to look around. WASD to move, Space/Ctrl for up/down, Shift/Alt for speed, Arrow keys to turn."},
                new ButtonInfo { buttonText = "Disable Stationary WASD Fly", toolTip = "When enabled, WASD fly stays in place when you stop moving."},
                new ButtonInfo { buttonText = "IronMonkey", method =() => Movement.IronMonke(), toolTip = "Fly like iron man."},
                new ButtonInfo { buttonText = "TpToStump", method =() => Movement.TpToStump(), toolTip = "Teleport to stump."},
                new ButtonInfo { buttonText = "TriggerFly", method =() => Movement.TriggerFly(), toolTip = "Fly with your right trigger."},
                new ButtonInfo { buttonText = "TagFreeze", method =() => Movement.TagFreeze(), toolTip = "Gives you tag freeze."},
                new ButtonInfo { buttonText = "NotagFreeze", method =() => Movement.NotagFreeze(), toolTip = "Gives you no tag freeze."},
                new ButtonInfo { buttonText = "SlingShotFly", method =() => Movement.SlingShotFly(), toolTip = "Makes you fly faster and faster."},
                new ButtonInfo { buttonText = "Noclip", method =() => Movement.Noclip(), toolTip = "Noclips you on right trigger."},
                new ButtonInfo { buttonText = "SpeedBoost", method =() => Movement.SpeedBoost(), toolTip = "Gives you a slight speedboost."},


            },

            new ButtonInfo[] { // Safety Mods [6]
                new ButtonInfo { buttonText = "Return to Main", method =() => currentCategory = 0, isTogglable = false, toolTip = "Returns to the main page of the menu."},

                new ButtonInfo { buttonText = "Anti Report", method =() => Safety.AntiReportDisconnect(), toolTip = "Disconnects you when someone tries to report you."},
            },

            new ButtonInfo[] { // Fun Mods [7]
                new ButtonInfo { buttonText = "Return to Main", method =() => currentCategory = 0, isTogglable = false, toolTip = "Returns to the main page of the menu."},

                new ButtonInfo { buttonText = "RGBMonkey", method =() => Fun.RGBMonke(), toolTip = "Makes your skid color go rgb."},
                new ButtonInfo { buttonText = "BugGun", method =() => Fun.BugGun(), toolTip = "A gun That gives you a bug."},
            },

            new ButtonInfo[] { // EnabledMods [8]
                new ButtonInfo { buttonText = "Return to Main", method =() => currentCategory = 0, isTogglable = false, toolTip = "Returns to the main page of the menu."},
                new ButtonInfo { buttonText = "EnabledMods", method =() => EnabledMods.Open(), toolTip = "Opens the EnebledMods tab."},
            },

            new ButtonInfo[] { // TimeChanger [9]
                new ButtonInfo { buttonText = "Return to Main", method =() => currentCategory = 0, isTogglable = false, toolTip = "Returns to the main page of the menu."},
                new ButtonInfo { buttonText = "Morning", method =() => TimeChanger.Morning(), isTogglable = false, toolTip = "Changes the time to morning."},
                new ButtonInfo { buttonText = "Day", method =() => TimeChanger.Day(), isTogglable = false, toolTip = "Changes the time to day."},
                new ButtonInfo { buttonText = "Evening", method =() => TimeChanger.Evening(), isTogglable = false, toolTip = "Changes the time to evening."},
                new ButtonInfo { buttonText = "Night", method =() => TimeChanger.Night(), isTogglable = false, toolTip = "Changes the time to night."},
            },


            new ButtonInfo[] { // Room [10]
                new ButtonInfo { buttonText = "Return to Main", method =() => currentCategory = 0, isTogglable = false, toolTip = "Returns to the main page of the menu."},
                new ButtonInfo { buttonText = "LobbyHop", method =() => Room.LobbyHop(), toolTip = "Takes you to a new lobby."},
            },

        };
    }
}
