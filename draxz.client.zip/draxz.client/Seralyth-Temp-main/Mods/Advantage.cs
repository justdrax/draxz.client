﻿using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using GorillaGameModes;
using BepInEx;
using GorillaLocomotion;
using SeralythTemp.Classes;
using SeralythTemp.Menu;
using UnityEngine.InputSystem;
using UnityEngine.XR;
using static SeralythTemp.Menu.Main;

namespace draxzclient.Mods
{
    internal class Advantage
    {
        //nothing yet
    }
}
