﻿using GorillaNetworking;
using SeralythTemp.Classes;
using SeralythTemp.Notifications;
using UnityEngine;

namespace SeralythTemp.Mods
{
    public class Room
    {
        public static void LobbyHop()
        {
            try
            {
                PhotonNetworkController pc = PhotonNetworkController.Instance;
                if (pc == null) return;

                GorillaNetworkJoinTrigger trigger = pc.currentJoinTrigger;
                if (trigger == null && pc.allJoinTriggers != null && pc.allJoinTriggers.Count > 0)
                {
                    trigger = pc.allJoinTriggers[0];
                }

                if (trigger == null) return;

                pc.AttemptToJoinPublicRoom(trigger, GorillaNetworking.JoinType.Solo, null, false);
            }
            catch { }
        }
    }
}