﻿using System;
using System.Collections.Generic;
using System.Text;
using GorillaLocomotion;
using GorillaNetworking;
using GorillaTag;
using GorillaTagScripts;
using GorillaTagScripts.ScavengerHunt;
using Photon.Pun;
using BepInEx;
using Technie.PhysicsCreator;
using UnityEngine;
using UnityEngine.InputSystem;
using SeralythTemp.Classes;
using SeralythTemp.Menu;
using UnityEngine.XR;
using static SeralythTemp.Menu.Main;

namespace draxzclient.Mods
{
    internal class Fun
    {

        public static void RGBMonke()
        {
            float time = Time.time * 1.8f;
            Color color = Color.HSVToRGB(Mathf.Repeat(time / (Mathf.PI * 2f), 1f), 1f, 1f);

            GorillaTagger.Instance.myVRRig.SendRPC(
                "RPC_InitializeNoobMaterial",
                RpcTarget.All,
                new object[] { color.r, color.g, color.b }
            );
        }

        public static bool previousBugTrigger;
        public static Vector3 ServerPos;
        public static ThrowableBug GetBug(Transform parent = null)
        {
            
            ThrowableBug bug = UnityEngine.Object.FindFirstObjectByType<ThrowableBug>();

            if (bug != null && parent != null)
            {
                bug.transform.SetParent(parent);
            }

            return bug;
        }
        public static void BugGun()
        {
            var input = ControllerInputPoller.instance;
            var tagger = GorillaTagger.Instance;

            if (input == null || tagger == null) return;

            if (input.rightGrab)
            {
                
                var gunData = RenderGun();
                GameObject pointer = gunData.NewPointer;

                float triggerValue = ControllerInputPoller.TriggerFloat(XRNode.RightHand);
                bool isTriggerPressed = triggerValue > 0.5f;

                
                if (isTriggerPressed && !previousBugTrigger && pointer != null)
                {
                    ServerPos = tagger.bodyCollider.transform.position;

                    ThrowableBug bug = GetBug(null);
                    if (bug != null)
                    {
                        bug.transform.position = pointer.transform.position;
                    }
                }

                
                previousBugTrigger = isTriggerPressed;
            }
        }
    }
}
