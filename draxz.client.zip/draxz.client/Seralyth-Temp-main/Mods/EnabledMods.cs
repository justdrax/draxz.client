﻿using BepInEx;
using GorillaLocomotion;
using SeralythTemp.Classes;
using SeralythTemp.Menu;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;
using static SeralythTemp.Menu.Main;

namespace SeralythTemp.Mods
{
    public class EnabledMods
    {
        public const int Category = 24;

        private static readonly HashSet<int> IgnoredCategories = new HashSet<int> { 1, 2, 3, 11, 12, 16, 21, 22, Category };

        public static void Open()
        {
            SeralythTemp.Menu.Buttons.buttons[Category] = BuildButtons();
            currentCategory = Category;
        }

        public static ButtonInfo[] BuildButtons()
        {
            List<ButtonInfo> menuButtons = new List<ButtonInfo>
            {
                new ButtonInfo
                {
                    buttonText = "Return to Main",
                    method = () => currentCategory = 0,
                    isTogglable = false,
                    toolTip = "Returns to the main page of the menu."
                },
                new ButtonInfo
                {
                    buttonText = "Refresh Enabled",
                    method = Open,
                    isTogglable = false,
                    toolTip = "Rescans your enabled mods."
                }
            };

            int activeCount = 0;
            var buttonCategories = SeralythTemp.Menu.Buttons.buttons;

            for (int categoryIndex = 0; categoryIndex < buttonCategories.Length; categoryIndex++)
            {
                if (IgnoredCategories.Contains(categoryIndex))
                    continue;

                foreach (ButtonInfo button in buttonCategories[categoryIndex])
                {
                    if (!button.isTogglable || !button.enabled)
                        continue;

                    ButtonInfo targetButton = button;
                    string displayName = targetButton.overlapText ?? targetButton.buttonText;

                    menuButtons.Add(new ButtonInfo
                    {
                        buttonText = "enabledmod" + activeCount++,
                        overlapText = displayName,
                        isTogglable = false,
                        toolTip = "Tap to turn off " + displayName + ".",
                        method = () => DisableSingleMod(targetButton)
                    });
                }
            }

            if (activeCount == 0)
            {
                menuButtons.Add(new ButtonInfo
                {
                    buttonText = "enabledmodnone",
                    overlapText = "No mods enabled",
                    isTogglable = false,
                    toolTip = "You have no mods turned on."
                });
            }
            else
            {
                menuButtons.Insert(2, new ButtonInfo
                {
                    buttonText = "Disable All Mods",
                    isTogglable = false,
                    toolTip = "Turns off every enabled mod at once.",
                    method = DisableAllActiveMods
                });
            }

            return menuButtons.ToArray();
        }

        private static void DisableSingleMod(ButtonInfo target)
        {
            target.enabled = false;
            target.disableMethod?.Invoke();

            Open();
        }

        private static void DisableAllActiveMods()
        {
            var buttonCategories = SeralythTemp.Menu.Buttons.buttons;

            for (int categoryIndex = 0; categoryIndex < buttonCategories.Length; categoryIndex++)
            {
                if (IgnoredCategories.Contains(categoryIndex))
                    continue;

                foreach (ButtonInfo button in buttonCategories[categoryIndex])
                {
                    if (button.isTogglable && button.enabled)
                    {
                        button.enabled = false;
                        button.disableMethod?.Invoke();
                    }
                }
            }

            Open();
        }
    }
}