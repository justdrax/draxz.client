﻿using SeralythTemp.Classes;
using SeralythTemp.Notifications;
using UnityEngine;

namespace SeralythTemp.Mods
{
    public class TimeChanger
    {
        public const int Category = 28;

        public static void Morning() => ApplyTimeSetting(TimePreset.Morning);
        public static void Day() => ApplyTimeSetting(TimePreset.Day);
        public static void Evening() => ApplyTimeSetting(TimePreset.Evening);
        public static void Night() => ApplyTimeSetting(TimePreset.Night);

        private enum TimePreset
        {
            Morning = 1,
            Day = 3,
            Evening = 5,
            Night = 7
        }

        private static void ApplyTimeSetting(TimePreset preset)
        {
            BetterDayNightManager manager = BetterDayNightManager.instance;
            if (manager == null) return;

            int totalPresets = manager.dayNightLightmapNames?.Length ?? 8;
            if (totalPresets == 0) return;

            float ratio = (int)preset / 8f;
            int targetIndex = Mathf.Clamp(Mathf.FloorToInt(ratio * totalPresets), 0, totalPresets - 1);

            manager.SetTimeOfDay(targetIndex, true);

            string statusText = manager.GetTimeOfDayString();
            if (!string.IsNullOrEmpty(statusText))
            {
                NotifiLib.SendNotification($"<color=grey>[</color><color=cyan>WEATHER</color><color=grey>]</color> {statusText}");
            }
        }
    }
}